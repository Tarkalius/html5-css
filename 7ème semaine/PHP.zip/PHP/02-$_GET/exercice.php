<?php
//EXERCICE : Créer un menu avec des liens 'hommes', 'femmes', 'enfants'.
//Faites en sorte d'afficher dans un <h1> SUR LA MEME PAGE la valeur passée dans l'URL lorsque l'on clique sur le lien
