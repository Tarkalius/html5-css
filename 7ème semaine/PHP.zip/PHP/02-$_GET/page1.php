<h1>Page 1</h1>

<a href="page2.php?article=jean&couleur=rouge&prix=123">Accéder à la page 2</a>