<p style="font-weight:bold;">Ici on ecrit n'importe quoi</p>

<p style='color:red;'>Il pourait y avoir du contenu html et/ou des traitements PHP</p>

<?php 

	$test = "Voici du contenu PHP";
	echo "<p> $test </p>";

?>
