<?php require_once "inc/header.inc.php"; ?>
<?php require_once "inc/nav.inc.php"; ?>

	<main>
		<section>
			<h2>Page 1</h2>
			<p>Contenu de la page 1</p>
			<p>Contenu de la page 1</p>
			<p>Contenu de la page 1</p>
			<p>Contenu de la page 1</p>
			<p>Contenu de la page 1</p>
			<p>Contenu de la page 1</p>
			<p>Contenu de la page 1</p>
		</section>
	</main>

<?php require_once "inc/footer.inc.php"; ?>
