<?php require_once "inc/header.inc.php"; //Inclusion du fichier header.inc.php qui se trouve dans un dossier inc ?>

<?php require_once 'inc/nav.inc.php'; ?>

		<main>
			<section>
				<h2>Page d'accueil</h2>
				<p>Contenu de la page accueil</p>
				<p>Contenu de la page accueil</p>
				<p>Contenu de la page accueil</p>
				<p>Contenu de la page accueil</p>
				<p>Contenu de la page accueil</p>
				<p>Contenu de la page accueil</p>
				<p>Contenu de la page accueil</p>
			</section>
		</main>
		
<?php require_once 'inc/footer.inc.php'; ?>