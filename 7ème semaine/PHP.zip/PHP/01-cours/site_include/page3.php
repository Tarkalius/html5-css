<?php require_once 'inc/header.inc.php'; ?>
<?php require_once 'inc/nav.inc.php'; ?>

	<main>
		<section>
			<h2>Page 3</h2>
			<p>Contenu de la page 3</p>
			<p>Contenu de la page 3</p>
			<p>Contenu de la page 3</p>
			<p>Contenu de la page 3</p>
			<p>Contenu de la page 3</p>
			<p>Contenu de la page 3</p>
			<p>Contenu de la page 3</p>
		</section>
	</main>

<?php require_once 'inc/footer.inc.php'; ?>