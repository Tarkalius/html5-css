<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>accueil</title>
	<link rel="stylesheet" type="text/css" href="">
</head>
<body>
	<div class="container">
		<header>
			<h1>MON SITE</h1>
		</header>