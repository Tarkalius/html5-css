<footer>
			<p> &copy; 2022 - Paris 75015</p>
		</footer>
	</div>
	<script type="text/javascript"></script>
</body>
</html>