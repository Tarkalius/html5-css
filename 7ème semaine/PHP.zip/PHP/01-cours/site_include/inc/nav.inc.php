		<nav>
			<ul>
				<li><a href="accueil.php">Accueil</a></li>
				<li><a href="page1.php">Page1</a></li>
				<li><a href="page2.php">Page2</a></li>
				<li><a href="page3.php">Page3</a></li>
			</ul>
		</nav>