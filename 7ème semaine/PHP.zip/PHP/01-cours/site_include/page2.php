<?php require_once "inc/header.inc.php"; ?>
<?php require_once "inc/nav.inc.php"; ?>

	<main>
		<section>
			<h2>Page 2</h2>
			<p>Contenu de la page 2</p>
			<p>Contenu de la page 2</p>
			<p>Contenu de la page 2</p>
			<p>Contenu de la page 2</p>
			<p>Contenu de la page 2</p>
			<p>Contenu de la page 2</p>
			<p>Contenu de la page 2</p>
		</section>
	</main>

<?php require_once "inc/footer.inc.php"; ?>
